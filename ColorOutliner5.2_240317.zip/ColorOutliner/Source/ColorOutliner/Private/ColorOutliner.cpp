// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutliner.h"

#include "LevelEditor.h"
#include "SceneOutlinerModule.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerMenuContext.h"
#include "SSceneOutliner.h"
#include "ToolMenu.h"
#include "ToolMenuDelegates.h"
#include "ToolMenuEntry.h"
#include "ToolMenuSection.h"
#include "ToolMenus.h"
#include "Widgets/Colors/SColorPicker.h"
#include "ActorFolderTreeItem.h"
#include "FSOItemLabelColumnReplace.h"
#include "SOutlinerTreeView.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Editor.h"
#include "EditorActorFolders.h"

#define LOCTEXT_NAMESPACE "FColorOutlinerModule"

namespace OFUtils = SceneOutlinerFolderUtils;

void FColorOutlinerModule::StartupModule()
{
	RegisterOnMapRename();
	RegisterOnMapDeleted();
	RegisterOnMapChanged();
	RegisterOnFolderOperate();
	RegisterOutlinerItemLabelColumn();
	RegisterOutlinerContextMenuExtend();
}

void FColorOutlinerModule::ShutdownModule()
{
	/*UnregisterOnMapRename*/
	if(OnPreWorldRenameHandle.IsValid()){FWorldDelegates::OnPreWorldRename.Remove(OnPreWorldRenameHandle);}
	if(OnPostWorldRenameHandle.IsValid()){FWorldDelegates::OnPostWorldRename.Remove(OnPostWorldRenameHandle);}
	
	/*UnregisterOnMapDeleted*/
	if(OnAssetsPreDeleteHandle.IsValid()){FEditorDelegates::OnAssetsPreDelete.Remove(OnAssetsPreDeleteHandle);}
	if(OnAssetsDeletedHandle.IsValid()){FEditorDelegates::OnAssetsDeleted.Remove(OnAssetsDeletedHandle);}
	
	/*UnregisterOnMapChanged*/
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	if(OnMapChangedHandle.IsValid()){LevelEditorModule.OnMapChanged().Remove(OnMapChangedHandle);}
	
	/*UnregisterOnFolderOperate*/
	if(OnFolderMovedHandle.IsValid()){FActorFolders::OnFolderMoved.Remove(OnFolderMovedHandle);}
	if(OnFolderDeletedHandle.IsValid()){FActorFolders::OnFolderDeleted.Remove(OnFolderDeletedHandle);}
	
	/*UnregisterOutlinerItemLabelColumn*/
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSOItemLabelColumnReplace>();
}

void FColorOutlinerModule::RegisterOnMapRename()
{
	OnPreWorldRenameHandle = FWorldDelegates::OnPreWorldRename.AddLambda([](UWorld* World, const TCHAR* InName, UObject* NewOuter, ERenameFlags Flags, bool& bShouldFailRename)
	{
		OFUtils::SaveMapOldName(World);
	});

	OnPostWorldRenameHandle = FWorldDelegates::OnPostWorldRename.AddLambda([](UWorld* World)
	{
		OFUtils::OnWorldPathPostChanged(World);
	});
}

void FColorOutlinerModule::RegisterOnMapDeleted()
{
	OnAssetsPreDeleteHandle = FEditorDelegates::OnAssetsPreDelete.AddLambda([](const TArray<UObject*>& Objects)
	{
		OFUtils::SavePathPreDelete(Objects);
	});
	
	OnAssetsDeletedHandle = FEditorDelegates::OnAssetsDeleted.AddLambda([](const TArray<UClass*>& Classes)
	{
		OFUtils::OnWorldDeleted();
	});
}

void FColorOutlinerModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedHandle = LevelEditorModule.OnMapChanged().AddLambda([&](UWorld* World, EMapChangeType MapChangeType)
	{
		FString NowMapPath;
		switch (MapChangeType)
		{
			case EMapChangeType::LoadMap:
				/*Template or existing*/
				NowMapPath = World->GetPathName();
				if(NowMapPath.StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
				{
					OFUtils::SetIsTempMap(true);
				}
				else
				{
					OFUtils::SetIsTempMap(false);
					NowMapPath.RemoveFromEnd(TEXT(".")+World->GetMapName());
					OFUtils::OLSetMapPath(NowMapPath);
				}
			break;
		
			case EMapChangeType::NewMap:
				/*Empty level*/
				OFUtils::SetIsTempMap(true);
			break;
		
			case EMapChangeType::SaveMap:
				/*Is template or empty level to save?*/
				if(OFUtils::GetIsTempMap())
				{
					OFUtils::TempToSave(World);
				}
			break;
		
			case EMapChangeType::TearDownWorld:
				/*Clear cache*/
				OFUtils::OLSetMapPath(FString());
				OFUtils::ClearFolderColorsTemp();
			break;
		}
	});
}

void FColorOutlinerModule::RegisterOnFolderOperate()
{
	OnFolderMovedHandle = FActorFolders::OnFolderMoved.AddLambda([](UWorld& World, const FFolder& Source, const FFolder& Dest)
	{
		OFUtils::SetIsFolderMoved(true);
		OFUtils::UpdateFullPath(Source,Dest);
	});
	
	OnFolderDeletedHandle = FActorFolders::OnFolderDeleted.AddLambda([]( UWorld& World, const FFolder& DeletedFolder )
	{
		if(!OFUtils::GetIsFolderMoved())
		{
			/*Not move,means delete*/
			OFUtils::DeleteFullPath(DeletedFolder);
		}
		else
		{
			OFUtils::SetIsFolderMoved(false);
		}
	});
}

void FColorOutlinerModule::RegisterOutlinerItemLabelColumn()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSceneOutlinerItemLabelColumn>();
	
	SceneOutlinerModule.RegisterDefaultColumnType<FSOItemLabelColumnReplace>(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 6));
}

void FColorOutlinerModule::RegisterOutlinerContextMenuExtend()
{
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(OFUtils::GetDefaultContextBaseMenuName());
	
	Menu->AddDynamicSection("SetFolderColorSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		USceneOutlinerMenuContext* Context = InMenu->FindContext<USceneOutlinerMenuContext>();
		if (!Context)
		{
			return;
		}
		FToolMenuSection& Section = InMenu->FindOrAddSection("SceneOutlinerFolderOptions");
		Section.Label = LOCTEXT("FolderOptionsLabel", "Folder Options");
		
		SelectedSceneOutliner = Context->SceneOutliner;
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		SceneOutliners = LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners();
		
		/*select and only select folder*/
		if (Context->NumSelectedItems > 0 && Context->NumSelectedFolders == Context->NumSelectedItems)
        {
			ExecuteFolderItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("OutlinerSetColorTooltip", "Sets the color this folder should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerExecutePickColor ) )
				);
			
			bool HasAnyItenSetColor = false;
			for(const FSceneOutlinerTreeItemPtr& Ttem : ExecuteFolderItems)
			{
				if(FActorFolderTreeItem* SelectedFolder = Ttem->CastTo<FActorFolderTreeItem>())
				{
					const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
		
					const TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
					OFUtils::GetFolderColorTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetFolderColor(FullPath);
					
					if (Color.IsSet())
					{
						if(Color.GetValue() != OFUtils::GetOutlinerFolderDefaultColor())
						{
							HasAnyItenSetColor = true;
							break;
						}
					}
				}
			}
			if(HasAnyItenSetColor)
			{
				Section.AddMenuEntry(
					"OutlinerClearColor",
					LOCTEXT("OutlinerClearColor", "Clear Color"),
					LOCTEXT("OutlinerClearColorTooltip", "Resets the color this folder appears as."),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerExecuteResetColor ))
					);
			}
        }
		else
		{
			SceneOutliners.Empty();
			ExecuteFolderItems.Empty();
		}
	}));
}

void FColorOutlinerModule::OutlinerExecutePickColor()
{
	// Spawn a color picker, so the user can select which color they want
	FLinearColor InitialColor = OFUtils::GetOutlinerFolderDefaultColor();
	
	// Make sure an color entry exists for all the paths, otherwise they won't update in realtime with the widget color
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteFolderItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
            
			TOptional<FLinearColor> Color = OFUtils::GetFolderColor(FullPath);
			if (Color.IsSet())
			{
				// Default the color to the first valid entry
				InitialColor = Color.GetValue();
				break;
			}
		}
	}

	FColorPickerArgs PickerArgs = FColorPickerArgs(InitialColor, FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged));
	PickerArgs.bIsModal = false;
	//PickerArgs.ParentWidget = ParentContent.Pin();

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OnLinearColorValueChanged(const FLinearColor InColor)
{
	OnColorClicked(InColor);
}

FReply FColorOutlinerModule::OnColorClicked(const FLinearColor InColor)
{
	for(const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteFolderItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			OFUtils::GetIsTempMap()?
				OFUtils::SaveFolderColorsTemp(SelectedFolder->GetPath().ToString(),InColor):
				OFUtils::SaveFolderColors(OFUtils::GetFolderFullPath(SelectedFolder),InColor);
		}
	}
	for(const TWeakPtr<ISceneOutliner>& Outliner : SceneOutliners)
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
	return FReply::Handled();
}

void FColorOutlinerModule::OutlinerExecuteResetColor()
{
	for(const FSceneOutlinerTreeItemPtr& Ttem : ExecuteFolderItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = Ttem->CastTo<FActorFolderTreeItem>())
		{
			OFUtils::GetIsTempMap()?
				OFUtils::DeleteFullPathTemp(SelectedFolder->GetPath().ToString()):
				OFUtils::DeleteFullPath(OFUtils::GetFolderFullPath(SelectedFolder));
		}
	}
	for(const TWeakPtr<ISceneOutliner>& Outliner : SceneOutliners)
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FColorOutlinerModule, ColorOutliner)